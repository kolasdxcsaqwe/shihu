package com.ye.tiger;

public class RequestBean {
	
	String url;
	boolean availbale;
	public boolean isAvailbale() {
		return availbale;
	}
	public void setAvailbale(boolean availbale) {
		this.availbale = availbale;
	}
	int sec;
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public int getSec() {
		return sec;
	}
	public void setSec(int sec) {
		this.sec = sec;
	}
	
	

}
